import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  AllAuthors:any;
  constructor(private _httpService: HttpService) { }

  ngOnInit() {
    this.Allauthor();
  }
  Allauthor() {
    this._httpService.allauthors().subscribe(data=> {
      this.AllAuthors = data;
      console.log(this.AllAuthors);
    })
  }

  Delete(id){
    this._httpService.delete(id).subscribe(data=>{
      if(data['status'] == 'gucci'){
        // this.Allauthor();
        this.ngOnInit();
        console.log(this.Allauthor);
      }
      else{
        console.log("didn't work");
      }
      // this.Deleteauthor = data;
      
    })
  }


}
