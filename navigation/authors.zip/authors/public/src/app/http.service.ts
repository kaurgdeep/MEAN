import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient){}

  createauthor(newauthor){
    console.log("got to service-createauthor",newauthor);
    return this._http.post('/author',newauthor);
  }
  allauthors(){
    console.log("go to service-allauthors");
    return this._http.get('/author');
   
  }
  delete(id){
    console.log("go to service-delete");
    return this._http.delete('/delete/'+id);
  }

  update(id,author){
    console.log("go to service-update");
    return this._http.put('/author/'+id,author);

  }
  getOneAuthor(id){
    console.log("go to service-getOneauthor");
    return this._http.get('/author/'+id);
   
  }

}
