import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Route, Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-newauthor',
  templateUrl: './newauthor.component.html',
  styleUrls: ['./newauthor.component.css']
})
export class NewauthorComponent implements OnInit {
  newauthor: { name: string };
  errors:any;

  constructor(private _httpService: HttpService, private _router: Router) { }

  ngOnInit() {
    this.newauthor = { name: ""}
  }
     
  onSubmit() {
    this._httpService.createauthor(this.newauthor).subscribe(data=> {
      if ('errors' in data){
        console.log('errors');
        this.errors = data['errors']['name']['message']
      }
      else{
        this.newauthor = { name: "" }
        console.log(data);
        this._router.navigate(['/home'])


      }
    })
  }


}
