import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-editauthor',
  templateUrl: './editauthor.component.html',
  styleUrls: ['./editauthor.component.css']
})
export class EditauthorComponent implements OnInit {
  updateauthor:any;
  OneAuthor:any;
  errors:any;
  constructor(
    private _httpService: HttpService,
    private _route: ActivatedRoute,
    private _router: Router
  ) { }

  ngOnInit() {
    this._route.params.subscribe((params: Params) =>{
      this.getOne(params['id']);
     console.log(params['id']);
    })  
  }

  getOne(id){
    this._httpService.getOneAuthor(id).subscribe(data=>{
      if(data === null || 'kind' in data){
        this._router.navigate(['/home'])
      }else{
        this.OneAuthor = data;
        console.log("get one author",this.OneAuthor);
      } 
    })
  }

  
  onupdateAuthor(){
    this._httpService.update(this.OneAuthor._id,this.OneAuthor).subscribe(data=>{
      if ('errors' in data){
        console.log(data.errors.name.message);
        this.errors = data.errors.name.message;
      }
      else{
        this.updateauthor = data;
        this.OneAuthor.name = "";
        this._router.navigate(['/home']);
        console.log("update",this.updateauthor);

      } 
    })
  }
}

