import { Component } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    AllAuthors:any;
    // Deleteauthor:any;
  constructor(private _httpService: HttpService){ }
    
  ngOnInit() {
    // this.Allauthor();
    
  }
     
  // Allauthor() {
  //   this._httpService.allauthors().subscribe(data=> {
  //     this.AllAuthors = data;
  //     console.log(this.AllAuthors);
  //   })
  // }

  // Delete(id){
  //   this._httpService.delete(id).subscribe(data=>{
  //     // this.Deleteauthor = data;
  //     this.Allauthor();
  //     console.log(this.Allauthor);
  //   })
  // }

}
